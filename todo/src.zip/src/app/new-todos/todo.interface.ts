export interface Todo {
  id?: number;
  name: string;
  complete?: boolean;
  isLoading?: boolean;
}
